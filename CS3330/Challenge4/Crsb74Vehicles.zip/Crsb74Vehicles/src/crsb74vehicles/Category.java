/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crsb74vehicles;

/**
 *
 * @author Caleb Sellinger
 */
public enum Category {
    MICRO, CONVERTIBLE, COUPE, SUPER_CAR, HATCHBACK, ROADSTER, SEDAN, CUV, SUV,
    WAGONS, MINI_VAN, VAN, PICKUP, CAMPER_VAN, TRUCK, SEMI_TRUCK, OTHER, UNKNOWN
}
